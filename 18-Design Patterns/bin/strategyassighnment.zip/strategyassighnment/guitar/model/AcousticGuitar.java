package strategyassighnment.guitar.model;

import strategyassighnment.guitar.behaviour.sound.Acoustic;
import strategyassighnment.guitar.behaviour.tuning.StandardTuning;

public class AcousticGuitar extends Guitar {

	public AcousticGuitar() {
		System.out.println("\n\n");
		showGuitarInfo();
		setSoundBehaviour(new Acoustic());
		System.out.print("Default ");
		sound();
		setTuningBehaviour(new StandardTuning());
		System.out.print("Default ");
		tune();
	}

	@Override
	public void showGuitarInfo() {
		System.out.println("\nGuitar type : Acoustic Guitar");
		playStyle();
		sound();
		tune();
	}
}
