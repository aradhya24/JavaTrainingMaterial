package strategyassighnment.guitar.behaviour.playingstyle;

public class Tapping implements IPlayingStyleBehaviour {

	@Override
	public void play() {
		System.out.println("Playing style : Tapping");
	}

}
