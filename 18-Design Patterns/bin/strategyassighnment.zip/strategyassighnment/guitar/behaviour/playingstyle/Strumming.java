package strategyassighnment.guitar.behaviour.playingstyle;

public class Strumming implements IPlayingStyleBehaviour{

	@Override
	public void play() {
		System.out.println("Playing style : Strumming");
	}

}
