package strategyassighnment.guitar.behaviour.playingstyle;

public interface IPlayingStyleBehaviour {
     public void play();
}
