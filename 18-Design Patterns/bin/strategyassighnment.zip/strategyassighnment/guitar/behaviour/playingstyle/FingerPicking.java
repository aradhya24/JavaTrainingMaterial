package strategyassighnment.guitar.behaviour.playingstyle;

public class FingerPicking implements IPlayingStyleBehaviour {

	@Override
	public void play() {
		System.out.println("Playing style : Finger Picking");
	}

}
