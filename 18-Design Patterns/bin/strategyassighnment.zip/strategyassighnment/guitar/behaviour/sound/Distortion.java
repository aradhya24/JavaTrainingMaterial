package strategyassighnment.guitar.behaviour.sound;

public class Distortion implements ISoundBehaviour {

	@Override
	public void sound() {
		System.out.println("Sound Type : Distortion");
	}

}
