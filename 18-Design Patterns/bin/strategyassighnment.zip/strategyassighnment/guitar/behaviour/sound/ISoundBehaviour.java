package strategyassighnment.guitar.behaviour.sound;

public interface ISoundBehaviour {
    public void sound();
}
