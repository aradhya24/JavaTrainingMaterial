package strategyassighnment.guitar.behaviour.sound;


public class Acoustic implements ISoundBehaviour {

	@Override
	public void sound() {
		System.out.println("Sound Type : Acoustic");
	}

}
