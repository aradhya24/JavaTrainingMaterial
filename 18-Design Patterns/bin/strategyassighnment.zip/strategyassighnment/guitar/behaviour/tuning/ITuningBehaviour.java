package strategyassighnment.guitar.behaviour.tuning;

public interface ITuningBehaviour {
     public void tuning();
}
