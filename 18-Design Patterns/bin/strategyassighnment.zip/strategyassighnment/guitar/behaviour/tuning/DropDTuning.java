package strategyassighnment.guitar.behaviour.tuning;

public class DropDTuning implements ITuningBehaviour {

	@Override
	public void tuning() {
		System.out.println("Tuning Type : Drop D");
	}

}
